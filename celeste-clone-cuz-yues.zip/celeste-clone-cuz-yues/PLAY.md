# First Light — Mountain Trials

## Play immediately

Open `frontend/public/game/index.html` in a desktop browser. The game is self-contained: no account, Python, build, package installation, or internet connection is needed. Keep the three JavaScript files alongside that HTML file. Alternatively, serve the folder with `python3 -m http.server 8000` and visit `http://localhost:8000/frontend/public/game/`.

To use the teacher's full application, follow the existing README setup instructions. Its home page now embeds the game and links to a full-page version. The original backend, login, admin and notes examples remain available.

## Controls

- Arrows or WASD: move and aim dash; Down also crouches / fast-falls.
- Z or Space: jump. Hold to jump higher, release for a short hop.
- X or K: dash in the aimed direction; no direction uses facing.
- C or Shift: grab a wall. Up climbs, Down descends; staying still costs less stamina.
- R: retry room. Escape: pause. Room picker: jump directly to any room.
- Sound can be enabled in the toolbar; it starts off.

## Rooms

1. First light: jump and dash fundamentals.
2. Hold on: springs, climbing, wall jumps and one-way platforms.
3. The crossing: cable lift and inherited momentum.
4. Loose stone: crumble, falling and dash-breakable blocks.
5. Wavedash workshop: an open runway and gap.
6. Summit route: combined movement and wallbounce practice.
7. Free practice: safe floor and walls for experiments.

All rooms and visuals are original. This is an inspired recreation, not a copy of Celeste's maps, artwork or soundtrack.

## Movement implemented

Fixed 60 Hz simulation, acceleration and air control, variable jump height, reduced gravity at the apex, jump and dash buffering, coyote time, eight-direction single dash, ground/crystal refills, fast fall, crouched hitbox and crouched dash entry, wall slides, wall jumps, neutral jumps, wall grabs, stamina and climb jumps, delayed stamina refunds, climb hops, upward and horizontal-dash corner correction, moving-solid carry/push, crush death and stored lift momentum.

The controller supports supers, hypers, extended supers/hypers, wavedashes, reverse dash jumps and wallbounces. Diagonal landings apply a momentum multiplier, providing an approximation of ultras. Speed is not globally clamped to running speed.

### Wavedash

In room 5, jump right, press Down+Right+X while airborne, then press Jump on landing. The refill gate opens 0.16 seconds after dash initiation. Jump too early and you can still hyper, but without another dash. The top of the game shows the technique and the HUD reports horizontal speed. Coral hair means a dash is available, blue means it is spent. Jump direction can be reversed on takeoff.

### Scope and fidelity

This is a playable approximation, **not complete frame-exact Celeste physics**. Corner boosts, wall boosts, lift interactions and ultras need further comparison against the real game. Some highly specific exploits (spike jumps, demohypers, corner kicks, grounded ultras and transition tricks) are not reproduced reliably. Dash freeze frames, exact wall-slide decay, semi-solid popping and all post-release collision fixes are not implemented. Ground friction, climb hops and moving-solid interactions are simplified. Berries collect immediately rather than following the player until a safe landing; they reset with the room and are session statistics. The falling-block collision model is simplified. No controller or touchscreen controls are provided.

Chapter 1-inspired physical objects included: solid and one-way terrain, spikes, springs, dash-refill crystals, strawberries, crumble platforms, touch/grab-triggered cable lifts, falling blocks, dash-breakable blocks and exit flags. There is no recreation of every Chapter 1 map, scripted event, secret or collectible rule, nor later-chapter objects such as dream blocks, feathers or bubbles.

## Change and test

- `frontend/public/game/physics.js`: mechanics; no rendering dependencies.
- `frontend/public/game/levels.js`: editable room rectangles and objects.
- `frontend/public/game/game.js`: rendering, input, sound, pause and local best times.
- `frontend/public/game/index.html`: standalone interface.
- `node frontend/tests/physics.cjs`: deterministic movement regressions.
- `make test`: original template checks plus movement regressions and browser tests.

Validation in the creation environment: 15 movement tests pass (including airborne wavedash, refill timing, wallbounce, jump height, coyote time, jump buffering, stamina, lift carry and anti-tunneling). Python tests, frontend unit tests, lint and production build passed. Browser verification could not run: Playwright's browser download was invalid, and the system Chromium launch was blocked by the runtime's socket restrictions. E2E tests are included but must be run on a machine with a working browser. Rooms have not been fully human-playtested; difficulty and edge cases may need tuning.

## References

Movement constants and concepts were checked against the developers' published learning resource and physics article:
- https://github.com/NoelFB/Celeste/blob/master/Source/Player/Player.cs
- https://maddymakesgames.com/articles/celeste_and_forgiveness/index.html

The JavaScript implementation here is independently written. No commercial game assets are included.
