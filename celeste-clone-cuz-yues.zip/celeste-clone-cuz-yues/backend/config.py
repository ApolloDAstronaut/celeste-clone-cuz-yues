"""Load backend settings from .env and keep them in one Settings object.

Edit this file when env variables, ports, cookie names, or dev/prod defaults change.
Do not copy this file. Change it when the app configuration model changes.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

from dotenv import load_dotenv

ROOT_DIR = Path(__file__).resolve().parent.parent
DEFAULT_COOKIE_SECRET = "change-this-secret"
DEFAULT_ADMIN_PASSWORD = "admin"
PLACEHOLDER_ADMIN_PASSWORDS = {DEFAULT_ADMIN_PASSWORD, "local-docker-admin", "playwright-admin", "change-this-password"}


@dataclass(slots=True)
class Settings:
    mode: str
    host: str
    port: int
    db_path: Path
    cookie_secret: str
    frontend_origin: str
    debug_logs: bool = True
    admin_password: str = DEFAULT_ADMIN_PASSWORD
    access_cookie_name: str = "template_access"
    refresh_cookie_name: str = "template_refresh"
    access_ttl_seconds: int = 2 * 60 * 60
    refresh_ttl_seconds: int = 60 * 24 * 60 * 60

    @property
    def secure_cookies(self) -> bool:
        return self.mode == "prod"

    @property
    def allowed_origins(self) -> set[str]:
        origins = {self.frontend_origin.rstrip("/")}
        if self.mode != "prod":
            origins.add(f"http://{self.host}:{self.port}")
            parsed = urlsplit(self.frontend_origin)
            if parsed.hostname == "127.0.0.1":
                origins.add(urlunsplit((parsed.scheme, f"localhost:{parsed.port}", parsed.path, parsed.query, parsed.fragment)).rstrip("/"))
            if parsed.hostname == "localhost":
                origins.add(urlunsplit((parsed.scheme, f"127.0.0.1:{parsed.port}", parsed.path, parsed.query, parsed.fragment)).rstrip("/"))
        return origins

    @property
    def migrations_path(self) -> Path:
        return ROOT_DIR / "backend" / "migrations"


def load_settings() -> Settings:
    load_dotenv(ROOT_DIR / ".env")
    mode = os.getenv("APP_MODE", "dev").strip().lower()
    host = os.getenv("APP_HOST", "localhost").strip()
    port = int(os.getenv("APP_PORT", "3101"))
    db_path = Path(os.getenv("DB_PATH", "./dev.sqlite3")).expanduser()
    if not db_path.is_absolute():
        db_path = ROOT_DIR / db_path
    cookie_secret = os.getenv("COOKIE_SECRET", DEFAULT_COOKIE_SECRET)
    # An empty value (for example an unset Docker variable) falls back to the dev default. Prod refuses that default.
    admin_password = os.getenv("ADMIN_PASSWORD") or DEFAULT_ADMIN_PASSWORD
    frontend_public_host = os.getenv("FRONTEND_PUBLIC_HOST", "localhost").strip()
    frontend_port = os.getenv("FRONTEND_PORT", "5101").strip()
    frontend_origin = os.getenv("FRONTEND_ORIGIN", f"http://{frontend_public_host}:{frontend_port}").rstrip("/")
    debug_logs = parse_bool_env(os.getenv("APP_DEBUG_LOGS"), default=mode != "prod")
    settings = Settings(
        mode=mode,
        host=host,
        port=port,
        db_path=db_path,
        cookie_secret=cookie_secret,
        frontend_origin=frontend_origin,
        debug_logs=debug_logs,
        admin_password=admin_password,
    )
    validate_settings(settings)
    return settings


def parse_bool_env(value: str | None, *, default: bool) -> bool:
    if value is None or value.strip() == "":
        return default
    normalized = value.strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    raise ValueError(f"Expected a boolean env value, got {value!r}. Use 1 or 0.")


def validate_settings(settings: Settings) -> None:
    if settings.mode not in {"dev", "test", "prod"}:
        raise ValueError("APP_MODE must be dev, test, or prod.")
    if settings.mode == "prod":
        if settings.cookie_secret in {DEFAULT_COOKIE_SECRET, "local-docker-secret", "agent-secret", "playwright-secret", "playwright-docker-secret"}:
            raise ValueError("Refusing to start in prod with a default COOKIE_SECRET. Set a real secret in your deploy environment.")
        if len(settings.cookie_secret.strip()) < 32:
            raise ValueError("Production COOKIE_SECRET must contain at least 32 characters. Use a long random secret.")
        if settings.admin_password.strip() in PLACEHOLDER_ADMIN_PASSWORDS or len(settings.admin_password.strip()) < 12:
            raise ValueError(
                "Production ADMIN_PASSWORD is missing or too weak. Add a password with at least 12 characters "
                "in the tlfpaas Secrets page and click Redeploy now."
            )
        if urlsplit(settings.frontend_origin).scheme != "https":
            raise ValueError("Production FRONTEND_ORIGIN must use https so secure login cookies work.")
