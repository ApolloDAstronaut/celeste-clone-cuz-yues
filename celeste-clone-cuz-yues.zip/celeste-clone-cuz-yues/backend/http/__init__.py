"""HTTP helpers and middleware."""
