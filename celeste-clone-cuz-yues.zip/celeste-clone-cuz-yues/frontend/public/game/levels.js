/* Original teaching rooms. Edit coordinates to design routes; copy a room to add a level. */
window.MountainLevels = (() => {
  const b = (x, y, w, h, kind = "stone", extra = {}) => ({ x, y, w, h, kind, ...extra });
  const i = (x, y, kind, w = 10, h = 10, extra = {}) => ({ x, y, w, h, kind, ...extra });
  const exit = (x, y) => i(x, y, "exit", 14, 24);
  return [
    {
      name: "01 / First light",
      hint: "Move • hold Jump for height • dash in any of eight directions",
      spawn: [24, 225],
      blocks: [b(0, 248, 125, 22), b(155, 224, 70, 46), b(258, 199, 65, 71), b(363, 174, 117, 96), b(0, 0, 8, 270)],
      items: [i(112, 240, "spike", 13, 8), i(240, 183, "refill"), i(290, 169, "berry"), exit(446, 150)],
    },
    {
      name: "02 / Hold on",
      hint: "Hold Grab + Up to climb. Release direction and jump for a neutral wall jump.",
      spawn: [26, 237],
      blocks: [b(0, 248, 110, 22), b(135, 166, 20, 104), b(205, 110, 20, 160), b(275, 155, 65, 12, "oneway"), b(372, 115, 108, 155)],
      items: [i(80, 242, "spring", 16, 6), i(172, 145, "refill"), i(242, 85, "berry"), i(285, 148, "spike", 24, 7), exit(450, 91)],
    },
    {
      name: "03 / The crossing",
      hint: "Ride the cable lift. Jump as it moves to inherit its momentum.",
      spawn: [22, 237],
      blocks: [b(0, 248, 86, 22), b(104, 226, 40, 12, "zip", { tx: 284, ty: 126 }), b(304, 175, 45, 12, "crumble"), b(384, 154, 96, 116), b(0, 0, 8, 270)],
      items: [i(212, 157, "berry"), i(347, 128, "refill"), exit(449, 130)],
    },
    {
      name: "04 / Loose stone",
      hint: "Crumbling platforms return. Dash through cracked blocks. Falling stone does not wait.",
      spawn: [22, 237],
      blocks: [
        b(0, 248, 90, 22),
        b(122, 220, 40, 12, "crumble"),
        b(190, 193, 40, 12, "crumble"),
        b(257, 164, 36, 20, "fall"),
        b(331, 127, 16, 74, "break"),
        b(347, 187, 133, 83),
      ],
      items: [i(300, 147, "refill"), i(365, 157, "berry"), i(405, 180, "spike", 24, 7), exit(452, 163)],
    },
    {
      name: "05 / Wavedash workshop",
      hint: "Jump → dash diagonally down → jump on landing. Wait ~0.16s after dash to keep your refill.",
      spawn: [30, 237],
      blocks: [b(0, 248, 225, 22), b(335, 248, 145, 22), b(0, 0, 8, 270)],
      items: [i(275, 211, "berry"), i(290, 224, "refill"), exit(452, 224)],
    },
    {
      name: "06 / Summit route",
      hint: "Chain your skills. Up-dash beside a wall + Jump = wallbounce. R retries the room.",
      spawn: [22, 237],
      blocks: [
        b(0, 248, 85, 22),
        b(109, 223, 35, 12, "zip", { tx: 184, ty: 169 }),
        b(237, 120, 16, 150),
        b(292, 153, 40, 12, "crumble"),
        b(376, 135, 104, 135),
      ],
      items: [i(206, 161, "refill"), i(275, 86, "berry"), i(350, 107, "refill"), i(395, 128, "spike", 20, 7), exit(450, 111)],
    },
    {
      name: "07 / Free practice",
      hint: "A safe lab for hypers, supers, wavedashes, reverses, wallbounces and lift boosts.",
      spawn: [30, 237],
      blocks: [b(0, 248, 480, 22), b(0, 0, 8, 270), b(472, 0, 8, 270), b(240, 155, 16, 93), b(325, 216, 40, 12, "zip", { tx: 404, ty: 124 })],
      items: [i(180, 185, "refill"), i(285, 165, "refill")],
    },
  ];
})();
