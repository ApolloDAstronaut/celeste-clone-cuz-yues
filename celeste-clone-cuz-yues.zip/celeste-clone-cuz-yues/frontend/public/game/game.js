/* Canvas rendering, keyboard input and local progress. Edit presentation here; copy for another game shell. */
"use strict";
const canvas = document.querySelector("#game"),
  ctx = canvas.getContext("2d");
const levels = window.MountainLevels,
  World = window.MountainPhysics.World;
let room = 0,
  paused = true,
  world = new World(levels[0]),
  acc = 0,
  last = 0,
  muted = true,
  audio = null,
  lastTech = "",
  shake = 0;
const keys = new Set(),
  pressed = new Set(),
  trails = [];
let best = {};
try {
  best = JSON.parse(localStorage.getItem("first-light-progress") || "{}");
} catch {}
const sel = document.querySelector("#rooms");
levels.forEach((l, n) => {
  const o = document.createElement("option");
  o.value = n;
  o.textContent = l.name;
  sel.append(o);
});
function load(n) {
  room = n;
  world = new World(levels[n]);
  sel.value = n;
  lastTech = "";
  trails.length = 0;
  document.querySelector("#hint").textContent = levels[n].hint;
}
function resume() {
  paused = false;
  document.querySelector("#overlay").hidden = true;
  keys.clear();
  pressed.clear();
  canvas.focus();
  acc = 0;
}
function pause() {
  paused = true;
  document.querySelector("#title").textContent = "Take a breath.";
  document.querySelector("#message").textContent = "Your climb is waiting. Resume when you are ready.";
  document.querySelector("#start").textContent = "Resume →";
  document.querySelector("#overlay").hidden = false;
  keys.clear();
  pressed.clear();
}
sel.onchange = () => {
  load(+sel.value);
  resume();
  sel.blur();
};
document.querySelector("#start").onclick = resume;
document.querySelector("#retry").onclick = () => {
  world.die();
  resume();
};
document.querySelector("#pause").onclick = () => (paused ? resume() : pause());
document.querySelector("#full").onclick = () => {
  if (document.fullscreenElement) document.exitFullscreen();
  else document.querySelector("main").requestFullscreen?.();
};
document.querySelector("#sound").onclick = () => {
  muted = !muted;
  document.querySelector("#sound").textContent = muted ? "Sound off" : "Sound on";
};
const controls = [
  "ArrowLeft",
  "ArrowRight",
  "ArrowUp",
  "ArrowDown",
  "Space",
  "KeyZ",
  "KeyX",
  "KeyC",
  "KeyW",
  "KeyA",
  "KeyS",
  "KeyD",
  "KeyK",
  "ShiftLeft",
  "ShiftRight",
];
window.addEventListener("keydown", (e) => {
  if (e.target === sel) return;
  if (controls.includes(e.code)) {
    e.preventDefault();
    if (!keys.has(e.code)) pressed.add(e.code);
    keys.add(e.code);
  }
  if (e.code === "Escape") paused ? resume() : pause();
  if (e.code === "KeyR" && !paused) world.die();
});
window.addEventListener("keyup", (e) => keys.delete(e.code));
window.addEventListener("blur", () => {
  if (!paused) pause();
});
document.addEventListener("visibilitychange", () => {
  if (document.hidden && !paused) pause();
});
const held = (...codes) => codes.some((c) => keys.has(c)),
  tap = (...codes) => codes.some((c) => pressed.has(c));
function beep(freq) {
  if (muted) return;
  try {
    audio ??= new AudioContext();
    const o = audio.createOscillator(),
      g = audio.createGain();
    o.type = "triangle";
    o.frequency.setValueAtTime(freq, audio.currentTime);
    o.frequency.exponentialRampToValueAtTime(freq / 2, audio.currentTime + 0.12);
    g.gain.setValueAtTime(0.05, audio.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, audio.currentTime + 0.15);
    o.connect(g);
    g.connect(audio.destination);
    o.start();
    o.stop(audio.currentTime + 0.15);
  } catch {}
}
function rect(x, y, w, h, color) {
  ctx.fillStyle = color;
  ctx.fillRect(Math.round(x), Math.round(y), w, h);
}
function poly(points, color) {
  ctx.fillStyle = color;
  ctx.beginPath();
  points.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
  ctx.closePath();
  ctx.fill();
}
function draw() {
  ctx.setTransform(2, 0, 0, 2, 0, 0);
  ctx.imageSmoothingEnabled = false;
  rect(0, 0, 480, 270, "#17283e");
  const t = world.time;
  // Layered original alpine silhouette, evening stars and windblown snow.
  for (let i = 0; i < 42; i++) rect((i * 79 + 31) % 480, (i * 37 + 11) % 150, 1, 1, i % 3 ? "#49647b" : "#aecbd6");
  ctx.fillStyle = "#b7d1d4";
  ctx.beginPath();
  ctx.arc(388, 45, 18, 0, Math.PI * 2);
  ctx.fill();
  poly(
    [
      [0, 210],
      [70, 90],
      [120, 150],
      [225, 34],
      [320, 154],
      [390, 91],
      [480, 207],
      [480, 270],
      [0, 270],
    ],
    "#243d53",
  );
  poly(
    [
      [179, 89],
      [225, 34],
      [264, 84],
      [239, 72],
      [225, 78],
      [211, 65],
    ],
    "#7f9eae",
  );
  poly(
    [
      [0, 238],
      [90, 164],
      [145, 213],
      [254, 133],
      [350, 220],
      [420, 158],
      [480, 208],
      [480, 270],
      [0, 270],
    ],
    "#2c4d62",
  );
  for (let j = 0; j < 8; j++) {
    const x = j * 71 - 12;
    poly(
      [
        [x - 20, 257],
        [x, 204],
        [x + 19, 257],
      ],
      "#183749",
    );
    rect(x - 2, 235, 4, 35, "#183749");
  }
  ctx.save();
  if (shake > 0) {
    ctx.translate(Math.sin(t * 140) * shake, Math.cos(t * 110) * shake);
    shake *= 0.8;
  }
  for (const b of world.blocks) {
    if (b.kind === "zip") {
      ctx.strokeStyle = "#8c7858";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(b.ox + b.w / 2, b.oy + 6);
      ctx.lineTo(b.tx + b.w / 2, b.ty + 6);
      ctx.stroke();
    }
    if (b.gone) {
      if (b.kind === "crumble") {
        ctx.strokeStyle = "#657784";
        ctx.setLineDash([2, 3]);
        ctx.strokeRect(b.x, b.y, b.w, b.h);
        ctx.setLineDash([]);
      }
      continue;
    }
    const col = b.kind === "zip" ? "#ad8054" : b.kind === "break" ? "#796682" : b.kind === "crumble" ? "#6d7c8c" : b.kind === "fall" ? "#8b7480" : "#3e5b70";
    rect(b.x, b.y, b.w, b.h, col);
    rect(b.x, b.y, b.w, 3, b.kind === "zip" ? "#e4bd75" : "#b5d7db");
    rect(b.x, b.y + 3, b.w, 2, "#7699a7");
    for (let y = b.y + 9; y < b.y + b.h; y += 12) for (let x = b.x + 4; x < b.x + b.w - 2; x += 16) rect(x, y, Math.min(9, b.x + b.w - x), 1, "#263e5370");
    if (b.kind === "zip") {
      rect(b.x + 4, b.y + 5, b.w - 8, b.h - 8, "#493d3e");
      rect(b.x + b.w / 2 - 2, b.y + 4, 4, 4, "#ffe6a1");
    }
    if (b.kind === "crumble") for (let x = b.x + 3; x < b.x + b.w; x += 6) rect(x, b.y + 6, 2, 2, "#d0d5cb");
    if (b.kind === "fall") for (let x = b.x + 4; x < b.x + b.w; x += 7) rect(x, b.y + 7, 2, 8, "#514451");
    if (b.kind === "break")
      poly(
        [
          [b.x + 5, b.y + 5],
          [b.x + 10, b.y + 18],
          [b.x + 6, b.y + 35],
          [b.x + 12, b.y + 48],
          [b.x + 8, b.y + 55],
        ],
        "#d3acbd",
      );
  }
  for (const i of world.items) {
    if (i.t && i.kind === "berry") continue;
    const bob = Math.sin(t * 3 + i.x) * 2;
    if (i.kind === "spike") {
      for (let x = i.x; x < i.x + i.w; x += 6)
        poly(
          [
            [x, i.y + i.h],
            [x + 3, i.y],
            [x + 6, i.y + i.h],
          ],
          "#e9cad1",
        );
    }
    if (i.kind === "spring") {
      rect(i.x, i.y + 3, i.w, 3, "#e295b5");
      rect(i.x + 3, i.y, i.w - 6, 3, "#ffd6dd");
    }
    if (i.kind === "refill") {
      poly(
        [
          [i.x + 5, i.y - 2 + bob],
          [i.x + 11, i.y + 5 + bob],
          [i.x + 5, i.y + 12 + bob],
          [i.x - 1, i.y + 5 + bob],
        ],
        i.t ? "#446072" : "#7cf4d6",
      );
      if (!i.t) rect(i.x + 4, i.y + 2 + bob, 2, 4, "#e0fff3");
    }
    if (i.kind === "berry") {
      poly(
        [
          [i.x, i.y + 2 + bob],
          [i.x + 10, i.y + 2 + bob],
          [i.x + 9, i.y + 8 + bob],
          [i.x + 5, i.y + 12 + bob],
          [i.x + 1, i.y + 8 + bob],
        ],
        "#ef789c",
      );
      rect(i.x + 3, i.y - 1 + bob, 5, 3, "#a0dbc1");
      rect(i.x + 3, i.y + 4 + bob, 1, 2, "#fff1d0");
      rect(i.x + 7, i.y + 5 + bob, 1, 2, "#fff1d0");
    }
    if (i.kind === "exit") {
      rect(i.x, i.y, 2, 24, "#cbe6df");
      poly(
        [
          [i.x + 2, i.y],
          [i.x + 15, i.y + 3],
          [i.x + 2, i.y + 9],
        ],
        "#95e2cb",
      );
    }
  }
  for (const a of trails) {
    ctx.globalAlpha = a.life * 0.7;
    rect(a.x, a.y, 8, 11, "#9bf8e4");
  }
  ctx.globalAlpha = 1;
  const p = world.p,
    x = p.x,
    y = p.y;
  const hair = p.dashes ? "#f18394" : "#72b8e8";
  rect(x - p.face * 3, y, 10, 7, hair);
  rect(x + 1, y + 4, 7, 6, "#81b7cd");
  rect(x + 2, y + 1, 5, 4, "#ffe1c6");
  rect(x + (p.face > 0 ? 6 : 2), y + 2, 1, 1, "#24334d");
  rect(x, y + 9, 3, 2, "#29314a");
  rect(x + 5, y + 9, 3, 2, "#29314a");
  if (held("KeyC", "ShiftLeft", "ShiftRight") && p.stamina < 110) {
    rect(x - 5, y - 6, 18, 2, "#354456");
    rect(x - 5, y - 6, (18 * p.stamina) / 110, 2, p.stamina < 25 ? "#ef789c" : "#9ee6cd");
  }
  for (let i = 0; i < 25; i++) rect(((i * 53 + t * 8) % 510) - 15, (i * 37 + t * 6) % 270, 1, 1, "#c5e4e688");
  ctx.restore();
  rect(10, 10, 152, 19, "#101b2bd9");
  ctx.fillStyle = "#d7e9ed";
  ctx.font = "8px monospace";
  ctx.fillText(levels[room].name.toUpperCase(), 17, 22);
  if (world.techTime > 0) {
    ctx.textAlign = "center";
    ctx.fillStyle = "#e5fff0";
    ctx.font = "bold 10px monospace";
    ctx.fillText(world.tech, 240, 31);
    ctx.textAlign = "left";
  }
  document.querySelector("#stats").textContent =
    `${world.time.toFixed(1)}s   /   ${world.deaths} deaths   /   ${world.berries} berries   /   ${Math.round(Math.abs(p.vx))} px/s${best[room] ? `   /   best ${best[room].toFixed(1)}s` : ""}`;
}
function frame(now) {
  const elapsed = Math.min((now - last) / 1000, 0.1);
  last = now;
  if (!paused) {
    acc += elapsed;
    while (acc >= 1 / 60) {
      world.tick({
        x: Number(held("ArrowRight", "KeyD")) - Number(held("ArrowLeft", "KeyA")),
        y: Number(held("ArrowDown", "KeyS")) - Number(held("ArrowUp", "KeyW")),
        jump: held("Space", "KeyZ"),
        jumpPressed: tap("Space", "KeyZ"),
        dashPressed: tap("KeyX", "KeyK"),
        grab: held("KeyC", "ShiftLeft", "ShiftRight"),
      });
      pressed.clear();
      acc -= 1 / 60;
      if (world.p.dash > 0) trails.push({ x: world.p.x, y: world.p.y, life: 0.3 });
      for (const a of trails) a.life -= 1 / 60;
      while (trails.length && trails[0].life <= 0) trails.shift();
      if (world.tech !== lastTech && world.techTime > 1.3) {
        beep(world.tech === "Try again" ? 120 : world.tech === "Strawberry" ? 800 : 440);
        if (world.tech === "Dash" || world.tech === "Try again") shake = 1.5;
        lastTech = world.tech;
      }
      if (world.won) {
        best[room] = Math.min(best[room] || Infinity, world.time);
        try {
          localStorage.setItem("first-light-progress", JSON.stringify(best));
        } catch {}
        if (room < 5) load(room + 1);
        else {
          paused = true;
          document.querySelector("#overlay").hidden = false;
          document.querySelector("#title").textContent = "You made it.";
          document.querySelector("#message").textContent = "The summit is yours. Head to Free practice to explore momentum and movement tech.";
          document.querySelector("#start").textContent = "Free practice →";
          document.querySelector("#start").onclick = () => {
            load(6);
            resume();
          };
        }
        break;
      }
    }
  }
  draw();
  requestAnimationFrame(frame);
}
load(0);
requestAnimationFrame(frame);
