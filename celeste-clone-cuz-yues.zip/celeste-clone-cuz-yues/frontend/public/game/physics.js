/* Fixed-step movement and room simulation. Edit to tune mechanics; copy for another platformer. */
(function (root) {
  "use strict";
  const approach = (v, t, d) => (v < t ? Math.min(v + d, t) : Math.max(v - d, t));
  const overlap = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
  class World {
    constructor(level) {
      this.load(level);
      this.deaths = 0;
      this.berries = 0;
    }
    load(level) {
      this.level = level;
      this.blocks = level.blocks.map((b) => ({ ...b, ox: b.x, oy: b.y, t: 0, phase: 0, vx: 0, vy: 0 }));
      this.items = (level.items || []).map((i) => ({ ...i, t: 0 }));
      this.p = {
        x: level.spawn[0],
        y: level.spawn[1],
        w: 8,
        h: 11,
        vx: 0,
        vy: 0,
        face: 1,
        dashes: 1,
        stamina: 110,
        ground: false,
        coyote: 0,
        buffer: 0,
        dash: 0,
        attack: 0,
        cool: 0,
        dx: 0,
        dy: 0,
        age: 9,
        varJump: 0,
        varSpeed: -105,
        lock: 0,
        lift: 0,
        lx: 0,
        ly: 0,
        refund: 0,
        dashBuffer: 0,
        duck: false,
      };
      this.time = 0;
      this.won = false;
      this.tech = "";
      this.techTime = 0;
    }
    solid(r, oldBottom = 0, dy = 0) {
      return this.blocks.find((b) => !b.gone && (b.kind !== "oneway" || (dy > 0 && oldBottom <= b.y + 0.1)) && overlap(r, b));
    }
    touching(side, range = 2) {
      const p = this.p;
      return this.solid({ ...p, x: p.x + side * range });
    }
    label(t) {
      this.tech = t;
      this.techTime = 1.4;
    }
    die() {
      this.deaths++;
      const d = this.deaths,
        b = this.berries;
      this.load(this.level);
      this.deaths = d;
      this.berries = b;
      this.label("Try again");
    }
    move(axis, amount) {
      const p = this.p;
      const n = Math.ceil(Math.abs(amount));
      if (!n) return;
      const step = amount / n;
      for (let j = 0; j < n; j++) {
        const old = p.y + p.h;
        const test = { ...p, [axis]: p[axis] + step };
        const hit = this.solid(test, old, axis === "y" ? step : 0);
        if (!hit) {
          p[axis] += step;
          continue;
        }
        if (axis === "x" && p.dash > 0 && p.dy === 0) {
          let fixed = false;
          for (let k = 1; k <= 4; k++) {
            if (!this.solid({ ...test, y: p.y - k })) {
              p.y -= k;
              p.x += step;
              fixed = true;
              break;
            }
          }
          if (fixed) continue;
        }
        if (axis === "y" && step < 0) {
          let fixed = false;
          for (let k = 1; k <= 4 && !fixed; k++)
            for (const s of [p.face, -p.face])
              if (!this.solid({ ...test, x: p.x + k * s })) {
                p.x += k * s;
                p.y += step;
                fixed = true;
                break;
              }
          if (fixed) continue;
        }
        if (hit.kind === "break" && p.attack > 0) {
          hit.gone = true;
          this.label("Smash");
          continue;
        }
        if (axis === "y") {
          if (step > 0) {
            p.ground = true;
            p.coyote = 0.1;
            if (p.attack > 0 && p.dy > 0 && p.dx) {
              p.vx = Math.sign(p.dx) * Math.max(240, Math.abs(p.vx) * 1.2);
              p.dash = 0;
              this.label("Dash landing");
            }
          }
          p.vy = 0;
        } else p.vx = 0;
        break;
      }
    }
    tick(input, dt = 1 / 60) {
      const p = this.p;
      this.time += dt;
      this.techTime -= dt;
      for (const k of ["coyote", "buffer", "dash", "attack", "cool", "varJump", "lock", "lift", "refund", "dashBuffer"]) p[k] = Math.max(0, p[k] - dt);
      p.age += dt;
      if (input.jumpPressed) p.buffer = 0.1;
      if (input.dashPressed) p.dashBuffer = 0.1;
      const duckWanted = input.y > 0 && (p.ground || p.dashBuffer > 0);
      if (duckWanted && !p.duck) {
        p.y += 5;
        p.h = 6;
        p.duck = true;
      } else if (!duckWanted && p.duck && !this.solid({ ...p, y: p.y - 5, h: 11 })) {
        p.y -= 5;
        p.h = 11;
        p.duck = false;
      }
      // Moving solids carry riders, push side contacts, and store momentum briefly.
      for (const b of this.blocks) {
        b.t += dt;
        const riding = Math.abs(p.y + p.h - b.y) < 1.5 && p.x + p.w > b.x && p.x < b.x + b.w;
        const near = overlap({ ...p, x: p.x - 2, w: p.w + 4 }, b);
        if (b.kind === "zip") {
          if ((riding || (input.grab && near)) && b.phase === 0) {
            b.phase = 1;
            b.t = 0;
          }
          const oldx = b.x,
            oldy = b.y;
          if (b.phase === 1) {
            const dist = Math.hypot(b.tx - b.x, b.ty - b.y);
            const v = Math.min(dist, 120 * dt);
            if (dist) {
              b.x += ((b.tx - b.x) / dist) * v;
              b.y += ((b.ty - b.y) / dist) * v;
            }
            if (dist < 1) {
              b.phase = 2;
              b.t = 0;
            }
          }
          if (b.phase === 2 && b.t > 0.6) b.phase = 3;
          if (b.phase === 3) {
            b.x = approach(b.x, b.ox, 45 * dt);
            b.y = approach(b.y, b.oy, 45 * dt);
            if (b.x === b.ox && b.y === b.oy) b.phase = 0;
          }
          b.vx = (b.x - oldx) / dt;
          b.vy = (b.y - oldy) / dt;
          if (riding) {
            p.x += b.x - oldx;
            p.y += b.y - oldy;
            p.lx = b.vx;
            p.ly = b.vy;
            p.lift = 0.16;
          } else if (overlap(p, b)) {
            p.x += b.x - oldx;
            p.y += b.y - oldy;
            if (this.blocks.some((o) => o !== b && !o.gone && o.kind !== "oneway" && overlap(p, o))) {
              this.die();
              return;
            }
          }
        }
        if (b.kind === "crumble") {
          if (riding && !b.phase) {
            b.phase = 1;
            b.t = 0;
          }
          if (b.phase === 1 && b.t > 0.5) {
            b.gone = true;
            b.phase = 2;
            b.t = 0;
          }
          if (b.phase === 2 && b.t > 2 && !overlap(p, b)) {
            b.gone = false;
            b.phase = 0;
          }
        }
        if (b.kind === "fall") {
          if ((riding || (input.grab && near)) && !b.phase) {
            b.phase = 1;
            b.t = 0;
          }
          if (b.phase === 1 && b.t > 0.4) {
            const dy = 120 * dt;
            b.y += dy;
            if (riding) p.y += dy;
            if (b.y > 300) b.gone = true;
          }
        }
      }
      const floor = this.solid({ ...p, y: p.y + 1 }, p.y + p.h, 1);
      p.ground = !!floor && p.vy >= 0;
      if (p.ground) {
        p.coyote = 0.1;
        p.stamina = 110;
        if (p.age >= 0.16) p.dashes = 1;
      } else p.coyote = Math.max(0, p.coyote);
      if (input.x) p.face = input.x;
      if (p.dashBuffer > 0 && p.dashes && p.cool === 0) {
        let x = input.x,
          y = input.y;
        if (!x && !y) x = p.face;
        const len = Math.hypot(x, y);
        p.dx = x / len;
        p.dy = y / len;
        p.vx = Math.sign(p.vx) === Math.sign(p.dx) ? Math.sign(p.dx) * Math.max(Math.abs(p.dx * 240), Math.abs(p.vx)) : p.dx * 240;
        p.vy = p.dy * 240;
        p.dashBuffer = 0;
        p.dash = 0.15;
        p.attack = 0.3;
        p.cool = 0.2;
        p.age = 0;
        p.dashes = 0;
        p.varJump = 0;
        this.label("Dash");
      }
      const wall = this.touching(-1) ? -1 : this.touching(1) ? 1 : 0;
      if (p.refund && input.x === -p.refundSide) {
        p.stamina = Math.min(110, p.stamina + 27.5);
        p.vx = input.x * 130;
        p.lock = 0.16;
        p.refund = 0;
        this.label("Stamina refund");
      }
      if (p.buffer > 0) {
        if (p.coyote > 0) {
          const hyper = p.attack > 0 && p.dy > 0 && p.dx !== 0,
            superJump = p.attack > 0 && p.dy === 0 && p.dx !== 0;
          p.vy = hyper ? -55 : -105;
          p.vx = hyper ? (input.x || Math.sign(p.dx)) * 325 : superJump ? (input.x || Math.sign(p.dx)) * 260 : p.vx + input.x * 40;
          if (p.lift) {
            p.vx += p.lx;
            p.vy += Math.min(0, p.ly);
          }
          if (hyper) this.label(p.dashes ? "Wavedash / extended hyper" : "Hyper");
          else if (superJump) this.label(p.dashes ? "Extended super" : "Super");
          p.dash = 0;
          p.attack = 0;
          p.coyote = 0;
          p.ground = false;
          p.buffer = 0;
          p.varJump = hyper ? 0.1 : 0.2;
          p.varSpeed = p.vy;
        } else {
          const bounce = p.attack > 0 && p.dy < 0 && (this.touching(-1, 5) ? -1 : this.touching(1, 5) ? 1 : 0);
          if (wall || bounce) {
            const side = bounce || wall;
            p.vy = bounce ? -160 : -105;
            if (input.grab && p.stamina > 27.5 && !bounce && input.x !== -side) {
              p.vx = 0;
              p.stamina -= 27.5;
              p.refund = 0.12;
              p.refundSide = side;
              this.label("Climb jump");
            } else {
              p.vx = -side * (bounce ? 170 : 130);
              p.lock = 0.16;
              this.label(bounce ? "Wallbounce" : input.x ? "Wall jump" : "Neutral jump");
            }
            p.dash = 0;
            p.attack = 0;
            p.buffer = 0;
            p.varJump = 0.2;
            p.varSpeed = p.vy;
          }
        }
      }
      if (!p.dash) {
        const grabbing = input.grab && wall && !p.ground && p.stamina > 0 && p.lock === 0;
        if (grabbing) {
          p.vx = 0;
          p.vy = approach(p.vy, input.y < 0 ? -45 : input.y > 0 ? 80 : 0, 900 * dt);
          p.stamina = Math.max(0, p.stamina - dt * (input.y < 0 ? 45.45 : input.y > 0 ? 0 : 10));
          if (input.y < 0 && !this.solid({ ...p, x: p.x + wall * 3, y: p.y - 7 })) {
            p.vx = wall * 65;
            p.vy = -80;
            p.lock = 0.15;
            this.label("Climb hop");
          }
        } else {
          if (!p.lock) {
            const target = input.x * 90;
            const accel = Math.abs(p.vx) > 90 && Math.sign(p.vx) === input.x ? 400 : 1000;
            p.vx = approach(p.vx, target, accel * (p.ground ? 1 : 0.65) * dt);
          }
          const gravity = input.jump && Math.abs(p.vy) < 40 ? 450 : 900;
          p.vy = approach(p.vy, input.y > 0 ? 240 : 160, gravity * dt);
          if (input.jump && p.varJump > 0) p.vy = Math.min(p.vy, p.varSpeed);
          if (!input.jump && p.vy < -40 && p.varJump > 0) {
            p.vy = -40;
            p.varJump = 0;
          }
          if (wall && input.x === wall && p.vy > 0 && p.stamina > 0) p.vy = Math.min(p.vy, 35);
        }
      }
      const vx = p.vx,
        vy = p.vy;
      this.move("x", vx * dt);
      this.move("y", vy * dt);
      for (const i of this.items) {
        i.t = Math.max(0, i.t - dt);
        if (i.t || !overlap(p, i)) continue;
        if (i.kind === "spike") {
          const safe = i.dir === "down" ? p.vy < 0 : i.dir === "left" ? p.vx > 0 : i.dir === "right" ? p.vx < 0 : p.vy < 0;
          if (!safe) {
            this.die();
            return;
          }
        }
        if (i.kind === "spring" && p.vy >= 0) {
          p.vy = -185;
          p.dash = 0;
          p.attack = 0;
          p.dashes = 1;
          p.stamina = 110;
          p.varJump = 0.2;
          p.varSpeed = -185;
          i.t = 0.15;
          this.label("Spring");
        }
        if (i.kind === "refill") {
          p.dashes = 1;
          p.stamina = 110;
          i.t = 2.5;
        }
        if (i.kind === "berry") {
          i.t = 99999;
          this.berries++;
          this.label("Strawberry");
        }
        if (i.kind === "exit") {
          this.won = true;
        }
      }
      if (p.y > 300 || p.x < 0 || p.x > 480) {
        this.die();
        return;
      }
    }
  }
  root.MountainPhysics = { World, overlap };
})(typeof module !== "undefined" ? module.exports : window);
