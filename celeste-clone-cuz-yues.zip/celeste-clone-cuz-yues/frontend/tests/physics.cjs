/* Regression tests for real movement outcomes. Edit when mechanics change; copy assertions for new tech. */
const { readFileSync } = require("node:fs");
const vm = require("node:vm");
const assert = require("node:assert/strict");
const test = require("node:test");
const box = { module: { exports: {} } };
vm.runInNewContext(readFileSync(__dirname + "/../public/game/physics.js", "utf8"), box);
const { World } = box.module.exports.MountainPhysics;
const level = { spawn: [30, 237], blocks: [{ x: 0, y: 248, w: 480, h: 22 }], items: [] };
const input = (x = {}) => ({ x: 0, y: 0, jump: false, jumpPressed: false, dashPressed: false, grab: false, ...x });
const step = (w, n, i = {}) => {
  for (let j = 0; j < n; j++) w.tick(input(i));
};
test("jump release produces a lower jump than holding", () => {
  const a = new World(level),
    b = new World(level);
  a.tick(input({ jump: true, jumpPressed: true }));
  b.tick(input({ jump: true, jumpPressed: true }));
  step(a, 8, { jump: true });
  step(b, 8);
  assert.ok(a.p.y < b.p.y - 5);
});
test("a dash is consumed and cannot be repeated in midair", () => {
  const w = new World(level);
  w.p.y = 80;
  w.tick(input({ x: 1, dashPressed: true }));
  assert.equal(w.p.dashes, 0);
  step(w, 14);
  w.tick(input({ y: -1, dashPressed: true }));
  assert.ok(w.p.vy >= 0);
});
test("extended hyper retains dash and launches at high speed", () => {
  const w = new World(level);
  w.tick(input({ x: 1, y: 1, dashPressed: true }));
  step(w, 10, { x: 1, y: 1 });
  w.tick(input({ x: 1, jump: true, jumpPressed: true }));
  assert.equal(w.p.dashes, 1);
  assert.ok(w.p.vx > 300);
  assert.ok(w.p.vy < 0);
  assert.match(w.tech, /Wavedash/);
});
test("early hyper launches but consumes dash", () => {
  const w = new World(level);
  w.tick(input({ x: 1, y: 1, dashPressed: true }));
  w.tick(input({ x: 1, jump: true, jumpPressed: true }));
  assert.equal(w.p.dashes, 0);
  assert.ok(w.p.vx > 300);
});
test("airborne wavedash lands and then jumps with refill", () => {
  const w = new World(level);
  w.p.y = 215;
  w.tick(input({ x: 1, y: 1, dashPressed: true }));
  let landed = false;
  for (let n = 0; n < 20; n++) {
    w.tick(input({ x: 1 }));
    if (w.p.ground && w.p.age >= 0.16) {
      landed = true;
      break;
    }
  }
  assert.ok(landed);
  w.tick(input({ x: 1, jump: true, jumpPressed: true }));
  assert.equal(w.p.dashes, 1);
  assert.ok(w.p.vx > 300);
  assert.ok(w.p.vy < 0);
});
test("wallbounce converts up dash into strong upward jump", () => {
  const w = new World({ ...level, blocks: [...level.blocks, { x: 42, y: 0, w: 20, h: 248 }] });
  w.p.y = 170;
  w.tick(input({ y: -1, dashPressed: true }));
  w.tick(input({ jump: true, jumpPressed: true }));
  assert.ok(w.p.vy < -140);
  assert.ok(w.p.vx < 0);
});
test("refill returns dash and stamina", () => {
  const w = new World({ ...level, items: [{ x: 30, y: 230, w: 15, h: 15, kind: "refill" }] });
  w.p.dashes = 0;
  w.p.stamina = 5;
  w.p.age = 0;
  w.tick(input());
  assert.equal(w.p.dashes, 1);
  assert.equal(w.p.stamina, 110);
});
test("spring launches, spikes kill, exit completes", () => {
  for (const kind of ["spring", "spike", "exit"]) {
    const w = new World({ ...level, items: [{ x: 30, y: 240, w: 15, h: 8, kind }] });
    w.tick(input());
    if (kind === "spring") assert.ok(w.p.vy < -180);
    if (kind === "spike") assert.equal(w.deaths, 1);
    if (kind === "exit") assert.equal(w.won, true);
  }
});
test("high speed motion cannot tunnel through a wall", () => {
  const w = new World({ ...level, blocks: [...level.blocks, { x: 80, y: 0, w: 8, h: 248 }] });
  w.p.vx = 1000;
  w.p.lock = 1;
  w.tick(input(), 0.1);
  assert.ok(w.p.x + w.p.w <= 80);
});
test("held jump clears a three-tile ledge", () => {
  const w = new World(level);
  w.tick(input({ jump: true, jumpPressed: true }));
  let top = w.p.y;
  for (let n = 0; n < 30; n++) {
    w.tick(input({ jump: true }));
    top = Math.min(top, w.p.y);
  }
  assert.ok(237 - top >= 24, `Jump rose only ${237 - top} pixels`);
});
test("coyote time allows a jump just after leaving a ledge", () => {
  const w = new World({ ...level, blocks: [{ x: 0, y: 248, w: 40, h: 22 }] });
  w.tick(input());
  w.p.x = 42;
  w.tick(input({ jumpPressed: true, jump: true }));
  assert.ok(w.p.vy < 0);
});
test("buffered jump fires when the ground is reached", () => {
  const w = new World(level);
  w.p.y = 235;
  w.p.vy = 120;
  w.tick(input({ jumpPressed: true, jump: true }));
  step(w, 2, { jump: true });
  assert.ok(w.p.vy < 0);
});
test("climbing spends stamina and release falls", () => {
  const w = new World({ ...level, blocks: [...level.blocks, { x: 38, y: 0, w: 20, h: 248 }] });
  w.p.y = 150;
  step(w, 15, { grab: true, y: -1 });
  assert.ok(w.p.stamina < 105);
  assert.ok(w.p.y < 150);
  step(w, 30);
  assert.ok(w.p.vy > 0 || w.p.ground);
});
test("moving platform carries the rider and stores lift speed", () => {
  const w = new World({ ...level, spawn: [30, 189], blocks: [{ x: 20, y: 200, w: 40, h: 12, kind: "zip", tx: 160, ty: 100 }] });
  step(w, 8);
  assert.ok(w.p.x > 30);
  assert.ok(w.p.lift > 0);
});
test("crumble platforms disappear and return", () => {
  const w = new World({ ...level, blocks: [{ x: 0, y: 248, w: 480, h: 22, kind: "crumble" }] });
  step(w, 32);
  assert.equal(w.blocks[0].gone, true);
  w.p.y = 20;
  w.p.vy = 0;
  w.blocks[0].t = 2.1;
  w.tick(input());
  assert.equal(w.blocks[0].gone, false);
});
