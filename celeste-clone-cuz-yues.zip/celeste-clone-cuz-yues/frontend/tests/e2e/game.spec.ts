/* Browser coverage of starting and selecting game rooms. Edit with game UI; copy for another play flow. */
import { test, expect } from "@playwright/test";
test("start climbing and select the wavedash workshop", async ({ page }) => {
  const errors: string[] = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await page.goto("/game/index.html");
  await page.getByRole("button", { name: "Start climbing" }).click();
  await expect(page.locator("#overlay")).toBeHidden();
  await page.keyboard.down("ArrowRight");
  await page.waitForTimeout(200);
  await page.keyboard.up("ArrowRight");
  await page.getByLabel("Choose room").selectOption("4");
  await expect(page.locator("#hint")).toContainText("diagonally down");
  await page.keyboard.press("Escape");
  await expect(page.locator("#overlay")).toBeVisible();
  expect(errors).toEqual([]);
});
