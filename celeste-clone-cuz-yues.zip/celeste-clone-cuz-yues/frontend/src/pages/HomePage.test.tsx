/* Verify that the public home exposes the playable game. Edit with the game entry; copy for a page test. */
import { render, screen } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { it, expect } from "vitest";
import { HomePage } from "./HomePage";
it("offers a standalone game and an embedded play area", () => {
  render(
    <MemoryRouter>
      <HomePage />
    </MemoryRouter>,
  );
  expect(screen.getByRole("link", { name: /Play First Light/ })).toHaveAttribute("href", "/game/index.html");
  expect(screen.getByTitle("First Light platformer")).toHaveAttribute("src", "/game/index.html");
});
